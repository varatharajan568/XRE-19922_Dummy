for f in *.dot; do
  [ -f "$f" ] || continue
  dot -Tpng "$f" -o "${f%.dot}.png"
done
